"""OCP-native STEP/BREP inspection utilities.

These functions are diagnostic tools, not modeling operations. They do not
record graph nodes and are not supported inside replayable modeling scripts.
Import the namespace as ``cadflow.inspect.brep``.
"""

from cadflow._engine.geometry.inspection.brep.compare import (
    BRepComparison,
    InspectionSummaryComparison,
    compare_inspections_rinspectionsummarycomparison,
    compare_shapes_rbrepcomparison,
    compare_steps_rbrepcomparison,
)
from cadflow._engine.geometry.inspection.brep.diagnostics import (
    compare_boundary_distance_rdescriptor,
    compare_entities_rdescriptor,
    compare_global_properties_rdescriptor,
    compare_material_rdescriptor,
    compare_sections_rdescriptor,
    evaluate_reconstruction_rdescriptor,
    inspect_difference_regions_rdescriptor,
    inspect_nearby_entities_rdescriptor,
)
from cadflow._engine.geometry.inspection.brep.inspect import (
    BRepInspection,
    inspect_shape_rbrepinspection,
    inspect_step_rbrepinspection,
)
from cadflow._engine.geometry.inspection.brep.io import load_step_rshape
from cadflow._engine.geometry.inspection.brep.model import (
    BRepEntityError,
    BRepModel,
    clear_step_model_cache_rnone,
    index_shape_rbrepmodel,
    inspect_step_entity_rdescriptor,
    inspect_step_rsummary,
    load_step_rbrepmodel,
)
from cadflow._engine.geometry.inspection.brep.parity import (
    EntityInspectionParity,
    compare_model_to_inspection_rentityinspectionparity,
    compare_step_to_inspection_rentityinspectionparity,
)
from cadflow._engine.geometry.inspection.brep.queries import (
    inspect_face_boundaries_rdescriptor,
    inspect_point_rdescriptor,
    inspect_section_rdescriptor,
    inspect_topology_neighborhood_rdescriptor,
    measure_entity_relation_rdescriptor,
    select_region_entities_rdescriptor,
)
from cadflow._engine.geometry.inspection.brep.render import (
    DEFAULT_VIEWS,
    inspect_step_components_rdescriptorlist,
    render_entity_kind_maps_rpath,
    render_entity_map_rpath,
    render_region_rpath,
    render_shape_views_rpath,
    render_step_components_colored_rpath,
    render_step_components_rpath,
    render_step_views_rpath,
)
from cadflow._engine.geometry.inspection.brep.slices import (
    SliceComparison,
    SlicePanelResult,
    SliceSpec,
    compare_shape_slices_rslicecomparison,
    compare_step_slices_rslicecomparison,
    make_center_slice_specs_rslicespeclist,
)

__all__ = [
    "BRepComparison",
    "BRepEntityError",
    "BRepInspection",
    "BRepModel",
    "DEFAULT_VIEWS",
    "EntityInspectionParity",
    "InspectionSummaryComparison",
    "SliceComparison",
    "SlicePanelResult",
    "SliceSpec",
    "clear_step_model_cache_rnone",
    "compare_boundary_distance_rdescriptor",
    "compare_entities_rdescriptor",
    "compare_global_properties_rdescriptor",
    "compare_inspections_rinspectionsummarycomparison",
    "compare_material_rdescriptor",
    "compare_model_to_inspection_rentityinspectionparity",
    "compare_sections_rdescriptor",
    "compare_shape_slices_rslicecomparison",
    "compare_shapes_rbrepcomparison",
    "compare_step_slices_rslicecomparison",
    "compare_step_to_inspection_rentityinspectionparity",
    "compare_steps_rbrepcomparison",
    "evaluate_reconstruction_rdescriptor",
    "index_shape_rbrepmodel",
    "inspect_difference_regions_rdescriptor",
    "inspect_face_boundaries_rdescriptor",
    "inspect_nearby_entities_rdescriptor",
    "inspect_point_rdescriptor",
    "inspect_section_rdescriptor",
    "inspect_shape_rbrepinspection",
    "inspect_step_components_rdescriptorlist",
    "inspect_step_entity_rdescriptor",
    "inspect_step_rbrepinspection",
    "inspect_step_rsummary",
    "inspect_topology_neighborhood_rdescriptor",
    "load_step_rbrepmodel",
    "load_step_rshape",
    "make_center_slice_specs_rslicespeclist",
    "render_entity_kind_maps_rpath",
    "render_entity_map_rpath",
    "render_region_rpath",
    "render_shape_views_rpath",
    "render_step_components_colored_rpath",
    "render_step_components_rpath",
    "render_step_views_rpath",
    "select_region_entities_rdescriptor",
]

# Inspection is an evidence-gathering boundary, not a modeling operation. Patch
# the defining modules too so direct submodule imports enforce the same rule.
from functools import wraps as _wraps
from inspect import isfunction as _isfunction
import sys as _sys

from cadflow._engine.workflow.graph import get_active_session as _get_active_session


def _outside_model_graph(function):
    @_wraps(function)
    def checked(*args, **kwargs):
        if _get_active_session() is not None:
            raise RuntimeError(
                "cadflow.inspect.brep tools cannot run inside an active "
                "GraphSession or @model function; inspect exported geometry "
                "outside the modeling script"
            )
        return function(*args, **kwargs)

    return checked


for _public_name in __all__:
    _public_value = globals()[_public_name]
    if not _isfunction(_public_value):
        continue
    _checked_value = _outside_model_graph(_public_value)
    globals()[_public_name] = _checked_value
    setattr(_sys.modules[_public_value.__module__], _public_name, _checked_value)

del _checked_value, _isfunction, _outside_model_graph, _public_name, _public_value
