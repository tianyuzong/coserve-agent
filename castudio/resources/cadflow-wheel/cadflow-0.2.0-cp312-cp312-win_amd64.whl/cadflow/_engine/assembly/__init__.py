"""Product and assembly modeling."""
